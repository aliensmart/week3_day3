from data import schema, seed


if __name__ == "__main__":
    schema()
    seed()
