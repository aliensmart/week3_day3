import sqlite3


def schema():
    pass