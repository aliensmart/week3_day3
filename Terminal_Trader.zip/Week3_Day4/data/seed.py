import sqlite3


def seed():
    pass
