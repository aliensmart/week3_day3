# Pokemon Lookup!!

API's exist for all sorts of meaningless data on the internet. One of these if the [Pokeapi](https://pokeapi.co/) which returns you all the Pokemon-related JSON you could possibly imagine (and then some).

Create a Python application that will keep prompting the user for pokemon names (command-line input) untilt they type `'done'`.  Then, it will return a dictionary of Pokemon: weight key-value pairs for every given name, if the name is a valid Pokemon.

Use the `requests` library and the pokeapi documentation to complete this assignment.